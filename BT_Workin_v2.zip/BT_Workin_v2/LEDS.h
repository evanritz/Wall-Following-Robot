/* 
 * File:   LEDS.h
 * Author: Evan
 *
 * Created on March 22, 2022, 6:30 PM
 */

#ifndef LEDS_H
#define	LEDS_H

void LED1_on(void);
void LED1_off(void);

void LED2_on(void);
void LED2_off(void);

void LED3_on(void);
void LED3_off(void);

void LED4_on(void);
void LED4_off(void);

#endif	/* LEDS_H */

