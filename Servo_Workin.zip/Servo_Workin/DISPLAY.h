/* 
 * File:   DISPLAY.h
 * Author: Evan
 *
 * Created on March 22, 2022, 7:40 PM
 */

#ifndef DISPLAY_H
#define	DISPLAY_H

void DISPLAY_print(char*);
void DISPLAY_print_double(char*, char*);


#endif	/* DISPLAY_H */